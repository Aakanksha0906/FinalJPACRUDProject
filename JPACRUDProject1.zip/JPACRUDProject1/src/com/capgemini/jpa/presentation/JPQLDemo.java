package com.capgemini.jpa.presentation;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.utility.JPAUtil;

public class JPQLDemo {
	
	public static void main(String[] args){
		
EntityManager entitymanager=
			           JPAUtil.getEntityManager();
//		String jql1="select e from Employee e";
//		TypedQuery<Employee>typedQuery1=
//				           entitymanager.createQuery(jql1,Employee.class);
//		List<Employee>employeeList=typedQuery1.getResultList();
//		showemployees(employeeList);
		
//		String jql2="select  e from Employee  WHERE e.job=:pjob AND salary>:psal";
//		TypedQuery<Employee>typedQuery=
//	           entitymanager.createQuery(jql2,Employee.class)
//	           .setParameter("pjob","Manager")
//	           .setParameter("psal",50000.00);
//	           List<Employee>employeeList=typedQuery.getResultList();
//             		showemployees(employeeList);
//	   		
//		
       Query query1=entitymanager.createNamedQuery("q1");
       List<Employee>employeeList=query1.getResultList();
       showemployees(employeeList);

	}
	private static void showemployees(List<Employee> employeeList) {
		Iterator<Employee>iterator=employeeList.iterator();
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}
		
	}

}
